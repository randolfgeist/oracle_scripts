prompt
prompt When generating large objects this script can make use of Parallel Execution on Enterprise Edition
prompt Default is to use serial execution (degree 1), enter a degree > 1 to make use of Parallel Execution during object creation
prompt

accept px_degree default '1' prompt 'Enter Parallel Degree to use for object creation (default 1): '

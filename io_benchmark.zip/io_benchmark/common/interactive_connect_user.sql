prompt
prompt Connecting as user &username now and executing benchmark as specified, continue when ready...
prompt

pause Hit CTRL+C to cancel, ENTER to continue

connect &username/&pwd.&connect_string2

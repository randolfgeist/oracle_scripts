prompt
prompt SUMMARY:
prompt
prompt User for benchmark:              &username
prompt Tablespace:                      &tablespace_name
prompt Blocksize:                       &block_size
prompt Number of slaves to start:       &num_slaves
prompt Number of blocks per object:     &num_rows
prompt Blocks required in tablespace:   &blocks_req_fm
prompt Space required in tablespace:    &object_size MB
prompt Temporary Tablespace:            &temp_tablespace
prompt Runtime in seconds:              &num_seconds
prompt Connect string:                  &connect_string
prompt Degree for object creation:      &px_degree
prompt O/S to use for spawning scripts: &os_name
prompt Performance report to create:    &perf_report

prompt
prompt In order to calculate the required space first enter the number of concurrent processes to start
prompt

accept num_slaves default '8' prompt 'Number of processes to start (default 8): '

